<br>
<div>
    <form action="./router.php?c=auth&a=logout" method="POST">
        <button type="submit" class="btn btn-primary">Logout</button>
    </form>
</div>
<br>