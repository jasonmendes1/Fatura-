Funcionário:
Username: jason
Password: 123456

Cliente:
Username: cliente
Password: 123456

Administrador
Username: administrador
Password: 123456

Github: https://github.com/jasonmendes1/Fatura-
